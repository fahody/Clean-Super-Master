package com.balaganovrocks.yourmasterclean.fragment;



import com.balaganovrocks.yourmasterclean.base.BaseFragment;


public class RelaxFragment extends BaseFragment {


}
